# Learn With Flow — Production Security Setup

## Owner authentication
Set a strong server-only environment variable before starting the server:

`OWNER_SECRET_KEY=<at least 32 random characters>`

Do not put this secret in React/Vite code, GitHub Pages, or any public repository.

The previous client-side fallback passwords were removed. If the authentication API is unavailable, the app now fails closed.

## Certificate verification
A QR code is only a URL. A verification ID becomes authoritative only when a persistent server-side certificate registry confirms it.

The current project contains the verification API contract but does **not** invent certificates in the backend. Before calling certificates "officially verified", connect `/api/certificates/verify/:id` to a persistent database and make certificate issuance server-side.

For a robust production design:
1. Store certificate records in Supabase/Postgres.
2. Issue certificates only after server-verified exam state.
3. Generate an unpredictable ID with `crypto.randomBytes`.
4. Store a hash/signature of the immutable certificate payload.
5. Return `valid: true` only for an existing, non-revoked record.
6. Put the public verification URL in the QR code.
7. Add revocation and audit timestamps.

## CAPTCHA
CAPTCHA providers require your own site key and server verification secret. Do not hard-code a fake key. For production, use Cloudflare Turnstile or reCAPTCHA and verify its token on the server before owner login/contact/other abuse-sensitive actions.

## YouTube
Use real public playlist IDs. A syntactically valid playlist ID is not proof that the playlist exists or permits embedding. If a creator disables embedding, YouTube can reject the iframe; the application should provide an external YouTube link instead of claiming the video is verified.

## Important
No browser-only app can provide a genuine 100% security guarantee. Authentication, certificate verification and exam integrity require trusted server-side controls.
