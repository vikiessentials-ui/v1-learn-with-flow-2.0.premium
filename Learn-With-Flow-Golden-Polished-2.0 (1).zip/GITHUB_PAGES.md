# GitHub Pages deployment

1. Upload this complete repository, not only `index.html`.
2. In GitHub open **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Push to `main` (or `master`). The included workflow builds Vite and publishes `dist`.
4. Wait for the Pages workflow to finish.

## Important production notes

- GitHub Pages is a static host. The secure Owner API in `server.ts` cannot execute on GitHub Pages.
- Do not put `OWNER_SECRET_KEY` or a YouTube Data API private key in frontend code.
- The certificate QR link is hash-based so it works on static hosting, but browser-local certificate records are not a public/global registry. For globally verifiable credentials, deploy `server.ts` plus a persistent database and use `VITE_API_BASE_URL` in the frontend.
- YouTube playlists must use real public playlist IDs. The project does not invent playlist IDs for courses that have no supplied playlist.
