# Learn With Flow — Golden Polish 3

## GitHub Pages
Upload the complete project files, not only `index.html`. This build is static-hosting friendly.

## YouTube playlists
The app will only embed a playlist when a real `playlistId` or valid YouTube playlist URL exists. It intentionally does **not** invent playlist IDs.

For the remaining courses, Owner Mode can store the real playlist URL. The player provides an exact course-specific YouTube search fallback rather than showing a fake “available” player.

## Languages
The UI includes English, Urdu, Hindi, Arabic and additional major language choices. Browser Speech Synthesis is used for voice playback; available voices depend on the visitor's browser/OS. This does not claim offline translation into every language.

## Security
GitHub Pages is static hosting. Do not put private API keys, CAPTCHA secrets or owner passwords in frontend JavaScript. Real certificate verification, secure owner authentication and anti-cheat controls require a backend.
