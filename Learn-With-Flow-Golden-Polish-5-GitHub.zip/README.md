# Learn With Flow — Golden Polish 5

## Included
- 182 technology course tracks.
- English-first interface with Urdu, Hindi, Arabic and additional language choices.
- Browser speech/read-aloud support where the visitor browser/OS provides the requested voice.
- YouTube playlist-first player: a course only reports a playlist as attached when a real playlist ID/URL is present.
- Owner dashboard for attaching genuine public playlist URLs.
- About CEO section with a dedicated **Credit to My Father — Muhammad Toseef** section.
- Lesson/module/final assessment flow and certificate UI.

## Critical integrity rule
This static GitHub build does **not** invent YouTube playlist IDs. A genuine exact-course playlist must be supplied and mapped before it is marked as attached. A YouTube search fallback is preferable to silently showing unrelated educational material.

## GitHub Pages
Keep `index.html` at repository root. Enable Settings → Pages → Deploy from a branch → `main` → `/ (root)`.

## Security note
GitHub Pages is static hosting. Never put private API keys, database credentials, CAPTCHA secrets, owner passwords, or certificate signing secrets in frontend code. Real certificate verification and secure owner authentication require a backend/database.
